#include <stdio.h>
int main () {
int numl = 35;
printf ("I'm Jefferson L. Russel, %d years of age", numl);
return 0;
}